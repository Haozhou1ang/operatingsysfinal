// client/include/cli/CliApp
#pragma once

class CliApp {
public:
  void Run();
};
