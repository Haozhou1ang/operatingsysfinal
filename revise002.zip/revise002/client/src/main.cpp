// client/src/main
#include "cli/CliApp.h"

int main() {
  CliApp app;
  app.Run();
  return 0;
}
